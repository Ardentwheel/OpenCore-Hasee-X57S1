Make sure your laptop is Hasee KingBook X57S1
Use IN1_BIOS_Update_Windows64.bat to update directly from Windows
Plug your laptop to AC adapter and don't touch it, until process is finished (laptop will reboot to BIOS
and update "itself")